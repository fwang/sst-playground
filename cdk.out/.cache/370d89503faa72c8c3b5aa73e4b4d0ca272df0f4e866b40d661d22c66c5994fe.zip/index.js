function handler() {
  return "f";
}

module.exports = { handler };